<!DOCTYPE html>
<html>
<head>
	<title>le site</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style7.css">
</head>
<body>

<header>
<?php include("menu.php");?>

	<div id="slid" >
		<figure>
			
			
			
			<img src="cour9.jpg">
			<img src="cfc1.jpg">
			<img src="cfc2.jpg">
			<img src="cfc3.jpg">
			<img src="cfc4.jpg">
			
			
        </figure>
   </div>
  <section id="sect">
<article>
<h1>LES NEWS DU JOUR </h1>
<p>Le procédé Manhès-David est un procédé d'affinage des mattes de cuivre inventé <br>en 1880 par l'industriel français Pierre Manhès et son ingénieur Paul David. Inspiré <br>du procédé Bessemer, il consiste en l'utilisation d'un convertisseur pour oxyder avec <br> de l'air les éléments chimiques indésirables (essentiellement le fer et le soufre) contenus dans <br>la matte afin de la transformer en cuivre.La quantité <br>des éléments à oxyder, ainsi que la faible chaleur produite <br>par les réactions chimiques, ont imposé des modifications du convertisseur. </p>
</article>
<aside>
	<h1>PRESENTATION</h1>
	<p><strong> GALAN TECHNOLOGIE</strong> est un site d'information conçu par un jeune<br> étudiant du nom de Sow Alpha Oumar ,ingénieur à l'INPT.Ce site permet de<br> partager des connaissances dans le domaine des NTICS et particulièrement<br> la programmation et le developpement des applications web.
</aside>

</section>
</header>
<footer>
	<?php include("pied_de_page.php");?>
</footer>

</body>
</html>