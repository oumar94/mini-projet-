
<!DOCTYPE html>
<html>
<head>
	<title>dispo</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="disp.css">
</head>
<body>
<br><br>
<form action="dispo_post1.php" method="post">
<label for="date_debut">Du </label>
	<input type="date" name="date_debut" value="" placeholder="15-07-2017" class="dateeee">
	<label for="date_fin">Au</label>
	<input type="date" name="date_fin" value="" placeholder="15-07-2017" class="dateeee">
	<input type="submit" name="valider" value="Rechercher" id="butt">
		
</form>
</body>
</html>