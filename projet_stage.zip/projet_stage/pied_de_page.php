<p>Copyright, tous droits reservés</p>
	<ul>
		    <li><a href="#">Plan du site</a></li>
			<li><a href="connexion.php">Espace Admin</a></li>
			<li><a href="#">Mentions legales</a></li>
	</ul>
	<div id="logo">
		<img src="fb-art.png">
		<img src="flickr.png">
		<img src="rss.png">
		<img src="inpt.png">
		<img src="ANRT1.png">

	</div>
	
