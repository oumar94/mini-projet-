<div id="menu">
<img src="logo7.png" id="log">
<ul id="navigation">
	<li><a href="interface.php?titre=accueil">Accueil</a></li>
    <li><a href="reservation.php?titre=reservation">Reservation</a></li>
	<li><a href="contact.php  ?titre=contact">Contacts</a></li>
</ul>
</div>